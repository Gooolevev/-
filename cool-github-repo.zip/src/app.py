#!/usr/bin/env python3
"""Минимальный пример Python CLI для запуска и тестов."""

import sys

def hello(name: str = "world") -> str:
    return f"Hello, {name}!"

def main():
    if len(sys.argv) >= 2:
        cmd = sys.argv[1]
        if cmd == "hello":
            name = sys.argv[2] if len(sys.argv) >= 3 else "world"
            print(hello(name))
        else:
            print("Available commands: hello")
    else:
        print("Usage: python src/app.py hello [name]")

if __name__ == '__main__':
    main()
